export declare const wait: (duration: number) => Promise<unknown>;
