/// <reference types="chrome" />
export declare const createNewTab: (options: chrome.tabs.CreateProperties) => Promise<unknown>;
