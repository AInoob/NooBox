interface IAjax {
    method?: 'GET' | 'POST' | 'DELETE';
    url: string;
    body?: string;
    headers?: {
        [index: string]: string;
    };
}
export declare const serialize: (obj: any) => string;
export declare const ajax: (params: IAjax) => Promise<string>;
export {};
