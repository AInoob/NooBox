export declare const voidFunc: () => void;
