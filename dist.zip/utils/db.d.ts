/// <reference types="react" />
import { IOptions } from '../background/options';
declare type KeyType = 'followersCleanCount' | keyof IOptions;
export declare const get: (key: KeyType, defaultValue?: any) => Promise<any>;
export declare const set: (key: KeyType, value: any) => Promise<unknown>;
export declare const bgSet: (key: KeyType, value: any) => Promise<void>;
export declare const getDB: (key: string) => Promise<any>;
export declare const setDB: (key: import("react").ReactText, value: any) => Promise<unknown>;
export declare const deleteDB: (key: string) => Promise<unknown>;
export {};
