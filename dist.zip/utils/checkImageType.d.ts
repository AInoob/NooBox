export declare const checkUrlOrBase64: (item: string) => "url" | "base64" | "unknown";
