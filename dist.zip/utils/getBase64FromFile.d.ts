export declare const getBase64FromFile: (file: File) => Promise<string | ArrayBuffer>;
