export declare const convertDataUriToBinary: (dataURI: string) => Uint8Array;
