import * as React from 'react';
export declare class Overview extends React.Component {
    constructor(props: any);
    render(): JSX.Element;
}
