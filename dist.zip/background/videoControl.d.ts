export declare class VideoControl {
    constructor();
    notifyAllToPerformSelfCheck(): void;
    notifyVideoControlSwitch(hostname: string, enabled: boolean): void;
    private setUpListener;
}
