export declare class Image {
    private imageUploadUrl;
    private imageDownloadUrl;
    private imageServerUrl;
    private imageSearchHandle;
    private extractImageHandle;
    private screenshotSearchHandle;
    constructor();
    init(): Promise<void>;
    updateImageSearchContextMenu(): Promise<void>;
    updateExtractImageContextMenu(): Promise<void>;
    updateScreenshotSearchContextMenu(): Promise<void>;
    private setUpListener;
    private updateImageUploadUrl;
    private updateImageDownloadUrl;
    private getImageServer;
    private screenshotSearch;
    private extractImages;
    private downloadExtractImages;
    private beginImageSearch;
}
