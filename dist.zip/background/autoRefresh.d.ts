export interface ITabStatus {
    handler?: any;
    interval: number;
    lastRefreshedAt: null | number;
    isFirstTimeInterval: boolean;
    firstTimeInterval: number;
}
export declare const defaultTabStatus: ITabStatus;
export interface IUpdateAutoRefresh {
    tabId: number;
    active: boolean;
    interval?: number;
    startAt?: number;
    shouldLogEvent?: boolean;
}
export declare class AutoRefresh {
    private tabs;
    constructor();
    private setUpListener;
    private clear;
    private performAutoRefresh;
    private delete;
    private update;
    private getSetting;
}
